import default_parser from 'kantord/dashboard'

new Navigo();



console.log(dashboard())
